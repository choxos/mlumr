## -----------------------------------------------------------------------------
# install.packages("mlumr")            # from CRAN
# # remotes::install_github("choxos/mlumr")   # development version

## -----------------------------------------------------------------------------
# library(mlumr)
# 
# ipd <- set_ipd(...)                  # individual patient data (index)
# agd <- set_agd(...)                  # aggregate data (comparator)
# dat <- combine_data(ipd, agd)        # combine
# dat <- add_integration(dat, ...)     # quasi-Monte Carlo integration points
# fit <- mlumr(dat, model = "spfa")    # fit the Bayesian model

